#ifndef _HEADER_H_
#define _HEADER_H_

#define MAXX_PRODUCTS 10
int return_max(int arr[], int n);


#endif